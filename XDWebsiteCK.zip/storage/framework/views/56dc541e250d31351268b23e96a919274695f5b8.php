

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>User</title>
  <!-- base:css -->
  <link rel="stylesheet" href="../../admin/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../admin/vendors/feather/feather.css">
  <link rel="stylesheet" href="../../admin/vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../admin/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../admin/images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../admin/partials/_navbar.html -->


    
    <!-- partial -->
   
    <div class="container-fluid page-body-wrapper">
    <?php echo $__env->make('admin.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Accounts Table</h4>
                  <!-- <p class="card-description">
                    Add class <code>.table</code>
                  </p> -->
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>UserName</th>
                          <th>Email</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Avatar</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                        <td>LamJay12</td>
                        <td>Lam@gmail.com</td>
                        <td>Tran</td>
                        <td>Lam</td>
                        <td>Hehehe</td>
                        </tr> 
                     </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../admin/partials/_footer.html -->
        <footer class="footer">

        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="../../admin/vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../admin/js/off-canvas.js"></script>
  <script src="../../admin/js/hoverable-collapse.js"></script>
  <script src="../../admin/js/template.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>

</html><?php /**PATH C:\wamp64\www\XDWebsiteCK\resources\views/admin/account/ListAccount.blade.php ENDPATH**/ ?>