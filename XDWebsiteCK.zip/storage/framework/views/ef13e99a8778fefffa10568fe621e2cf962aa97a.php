
<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <div class="user-profile">
          <div class="user-image">
            <img src="../../admin/images/avatar.png">
          </div>
          <div class="user-name">
            <?php if(session('role_id')): ?>
              <?php if(session('email')): ?>
                Hi, <?php echo e(session('email')); ?>

              <?php endif; ?>
            <?php endif; ?>
          </div>
          <div class="user-designation">
              
          </div>
        </div>
        <ul class="nav">
          
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('listAccount')); ?>">
              <i class="icon-head menu-icon"></i>
              <span class="menu-title">Accounts</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('listCourse')); ?>">
              <i class="icon-command menu-icon"></i>
              <span class="menu-title">Courses</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('listCategory')); ?>">
              <i class="icon-stack menu-icon"></i>
              <span class="menu-title">Categories</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('listVideo')); ?>">
              <i class="icon-video menu-icon"></i>
              <span class="menu-title">Videos</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../part_videos/ListPartVideos.php">
              <i class="icon-grid menu-icon"></i>
              <span class="menu-title">Part Videos</span>
            </a>
          </li>
        </ul>
      </nav>
<?php /**PATH C:\wamp64\www\XDWebsiteCK\resources\views/admin/layout/menu.blade.php ENDPATH**/ ?>