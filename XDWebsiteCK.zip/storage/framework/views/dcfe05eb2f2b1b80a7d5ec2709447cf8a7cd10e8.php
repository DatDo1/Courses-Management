<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Category</title>
  <!-- base:css -->
  <link rel="stylesheet" href="../../../admin/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../../admin/vendors/feather/feather.css">
  <link rel="stylesheet" href="../../../admin/vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../../admin/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../../admin/images/favicon.png" />
</head>

<body>
  
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">

      <!-- partial:../../../admin/partials/_sidebar.html -->
    
      <?php echo $__env->make('admin.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">List Categories</h4>
                  <!-- <p class="card-description">
                    Add class <code>.table</code>
                  </p> -->
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                        <td>id</td>
                        <td>name</td>
                        <td>
                    <button name = 'edit' value ='id' class='btn btn-success'><b class='mdi mdi-upload btn-icon-prepend'>Sửa</b></button>
                    <button name = 'delete' value = 'id' class='btn btn-danger'><b class='mdi mdi-alert btn-icon-prepend'>Xóa</b></button>
                  </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../../admin/partials/_footer.html -->
        <footer class="footer">

        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="../../../admin/vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../../admin/js/off-canvas.js"></script>
  <script src="../../../admin/js/hoverable-collapse.js"></script>
  <script src="../../../admin/js/template.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>

</html><?php /**PATH C:\wamp64\www\XDWebsiteCK\resources\views/admin/category/ListCategory.blade.php ENDPATH**/ ?>